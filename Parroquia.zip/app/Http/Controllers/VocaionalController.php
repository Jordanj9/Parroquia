<?php

namespace App\Http\Controllers;

use App\vocaional;
use Illuminate\Http\Request;

class VocaionalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\vocaional  $vocaional
     * @return \Illuminate\Http\Response
     */
    public function show(vocaional $vocaional)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\vocaional  $vocaional
     * @return \Illuminate\Http\Response
     */
    public function edit(vocaional $vocaional)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\vocaional  $vocaional
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, vocaional $vocaional)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\vocaional  $vocaional
     * @return \Illuminate\Http\Response
     */
    public function destroy(vocaional $vocaional)
    {
        //
    }
}
