<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Sacramento;
use Faker\Generator as Faker;

$factory->define(Sacramento::class, function (Faker $faker) {
    return [
        //
    ];
});
