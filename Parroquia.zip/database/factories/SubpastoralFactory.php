<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Subpastoral;
use Faker\Generator as Faker;

$factory->define(Subpastoral::class, function (Faker $faker) {
    return [
        //
    ];
});
