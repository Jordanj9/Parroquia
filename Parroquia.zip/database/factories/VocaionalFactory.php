<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\vocaional;
use Faker\Generator as Faker;

$factory->define(vocaional::class, function (Faker $faker) {
    return [
        //
    ];
});
