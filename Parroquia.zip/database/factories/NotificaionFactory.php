<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Notificaicon;
use Faker\Generator as Faker;

$factory->define(Notificaicon::class, function (Faker $faker) {
    return [
        //
    ];
});
