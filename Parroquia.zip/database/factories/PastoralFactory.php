<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Pastoral;
use Faker\Generator as Faker;

$factory->define(Pastoral::class, function (Faker $faker) {
    return [
        //
    ];
});
