<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Miembro;
use Faker\Generator as Faker;

$factory->define(Miembro::class, function (Faker $faker) {
    return [
        //
    ];
});
