<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Planpastoral;
use Faker\Generator as Faker;

$factory->define(Planpastoral::class, function (Faker $faker) {
    return [
        //
    ];
});
