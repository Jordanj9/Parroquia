<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Comunidad;
use Faker\Generator as Faker;

$factory->define(Comunidad::class, function (Faker $faker) {
    return [
        //
    ];
});
