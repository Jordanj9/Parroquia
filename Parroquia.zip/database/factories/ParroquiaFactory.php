<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Parroquia;
use Faker\Generator as Faker;

$factory->define(Parroquia::class, function (Faker $faker) {
    return [
        //
    ];
});
