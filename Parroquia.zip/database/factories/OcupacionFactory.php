<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ocupacion;
use Faker\Generator as Faker;

$factory->define(ocupacion::class, function (Faker $faker) {
    return [
        //
    ];
});
