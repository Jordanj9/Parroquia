<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Estadocivil;
use Faker\Generator as Faker;

$factory->define(Estadocivil::class, function (Faker $faker) {
    return [
        //
    ];
});
