<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Administracion;
use Faker\Generator as Faker;

$factory->define(Administracion::class, function (Faker $faker) {
    return [
        //
    ];
});
